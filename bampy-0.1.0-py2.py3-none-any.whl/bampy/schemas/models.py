from enum import Enum


class ModelType(str, Enum):
    BLOOM = "bigscience/bloom"
    BLOOMZ = "bigscience/bloomz"
    CODEGEN_MONO_16B = "salesforce/codegen-16b-mono"
    FLAN_T5 = "google/flan-t5-xxl"
    GPT_NEOX_20B = "eleutherai/gpt-neox-20b"
    MT0 = "bigscience/mt0-xxl"
    SANTA_CODER = "bigcode/santacoder"
    UL2 = "google/ul2"
