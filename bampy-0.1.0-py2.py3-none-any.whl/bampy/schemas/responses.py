from datetime import datetime
from enum import Enum
from typing import List, Optional

from pydantic import BaseModel, Extra

from bampy.schemas.generate_params import GenerateParams
from bampy.schemas.models import ModelType


class TermsOfUse(BaseModel):
    tou_accepted: bool
    tou_accepted_at: datetime


class StopReasonEnum(str, Enum):
    NOT_FINISHED = "Possibly more tokens to be streamed"
    MAX_TOKENS = "Maximum requested tokens reached"
    EOS_TOKEN = "End of sequence token encountered"
    CANCELLED = "Request canceled by the client"
    TIME_LIMIT = "Time limit reached"
    STOP_SEQUENCE = "Stop sequence encountered"
    TOKEN_LIMIT = "Token limit reached"
    ERROR = "Error encountered"


class GenerateResult(BaseModel):
    generated_text: str
    generated_token_count: int
    input_token_count: Optional[int]
    stop_reason: str

    class Config:
        extra: Extra.allow


class GenerateResponse(BaseModel):
    model_id: ModelType
    created_at: datetime
    results: List[GenerateResult]

    class Config:
        extra: Extra.allow


class TokenizeResult(BaseModel):
    token_count: int
    tokens: List[str]

    class Config:
        extra: Extra.allow


class TokenizeResponse(BaseModel):
    model_id: ModelType
    created_at: datetime
    results: List[TokenizeResult]

    class Config:
        extra: Extra.allow


class HistoryResultRequest(BaseModel):
    inputs: list[str]
    model_id: str
    parameters: GenerateParams

    class Config:
        extra: Extra.allow


class HistoryResult(BaseModel):
    id: str
    duration: int
    request: HistoryResultRequest
    status: str
    created_at: datetime
    response: GenerateResponse

    class Config:
        extra: Extra.allow


class HistoryResponse(BaseModel):
    results: List[HistoryResult]
    totalCount: int

    class Config:
        extra: Extra.allow


class ErrorResponse(BaseModel):
    status_code: int
    error: str
    message: str

    class Config:
        extra: Extra.allow
