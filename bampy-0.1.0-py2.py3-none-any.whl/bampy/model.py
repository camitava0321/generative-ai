import logging
from collections.abc import Generator
from typing import Any, Callable

from bampy.credentials import Credentials
from bampy.exceptions import BAMException
from bampy.metadata import Metadata
from bampy.schemas import GenerateParams, ModelType, TokenParams
from bampy.schemas.responses import (
    GenerateResponse,
    GenerateResult,
    TokenizeResponse,
    TokenizeResult,
)
from bampy.services import AsyncRequestHelper, ServiceInterface


class Model:
    def __init__(self, model: ModelType, params: GenerateParams, credentials: Credentials):
        """Instansiates the Model Interface

        Args:
            model (ModelType): The type of model to use
            params (GenerateParams): Parameters to use during generate requests
            credentials (Credentials): The API Credentials
        """
        logging.debug(
            f"Model Created:  Model: {model}, key: {credentials.api_key}, endpoint: {credentials.api_endpoint}"
        )
        self.model = model
        self.params = params
        self.service = ServiceInterface(service_url=credentials.api_endpoint, api_key=credentials.api_key)

    def generate_as_completed(self, prompts: list[str]) -> Generator[GenerateResponse]:
        """The generate endpoint is the centerpiece of the BAM alpha.
        It provides a simplified and flexible, yet powerful interface to the supported
        models as a service. Given a text prompt as inputs, and required parameters
        the selected model (model_id) will generate a completion text as generated_text.

        Args:
            prompts (list[str]): The list of one or more prompt strings.

        Yields:
            Generator[GenerateResult]: A generator of results
        """
        logging.debug(f"Calling Generate. Prompts: {prompts}, params: {self.params}")

        try:
            for i in range(0, len(prompts), Metadata.DEFAULT_MAX_PROMPTS):
                response_gen = self.service.generate(
                    self.model,
                    prompts[i : min(i + Metadata.DEFAULT_MAX_PROMPTS, len(prompts))],
                    self.params,
                )
                if response_gen.status_code == 200:
                    responses = GenerateResponse(**response_gen.json())

                    for result in responses.results:
                        yield result
                else:
                    raise BAMException(response_gen)
        except BAMException as me:
            raise me
        except Exception as ex:
            raise BAMException(ex)

    def generate(self, prompts: list[str]) -> list[GenerateResponse]:
        """The generate endpoint is the centerpiece of the BAM alpha.
        It provides a simplified and flexible, yet powerful interface to the supported
        models as a service. Given a text prompt as inputs, and required parameters
        the selected model (model_id) will generate a completion text as generated_text.

         Args:
            prompts (list[str]): The list of one or more prompt strings.

        Returns:
            list[GenerateResult]: A list of results
        """
        return list(self.generate_as_completed(prompts))

    def generate_async(
        self, prompts: list[str], callback: Callable[[GenerateResult], Any] = None
    ) -> list[GenerateResponse]:
        """The generate endpoint is the centerpiece of the BAM alpha.
        It provides a simplified and flexible, yet powerful interface to the supported
        models as a service. Given a text prompt as inputs, and required parameters
        the selected model (model_id) will generate a completion text as generated_text.
        This python method generates responses utilizing async capabilities and returns
        responses as they arrive.

        Args:
            prompts (list[str]): The list of one or more prompt strings.
            callback (Callable[[GenerateResult], Any]): Optional callback
                to be called after generating result for a prompt.

        Returns:
            list[GenerateResult]: A list of results
        """
        logging.debug(f"Calling Generate Async. Prompts: {prompts}, params: {self.params}")

        try:
            with AsyncRequestHelper(self.model, prompts, self.params, self.service, callback=callback) as asynchelper:
                for response in asynchelper.generate():
                    for result in response.results:
                        yield result
        except BAMException as me:
            raise me
        except Exception as ex:
            raise BAMException(ex)

    def tokenize_as_completed(self, inputs: list[str], return_tokens: bool = False) -> Generator[TokenizeResponse]:
        """The tokenize endpoint allows you to check the conversion of provided inputs to tokens
        for a given model. It splits text into words or subwords, which then are converted to ids
        through a look-up table (vocabulary). Tokenization allows the model to have a reasonable
        vocabulary size.

        Args:
            return_tokens (bool, optional): Return tokens with the response. Defaults to False.

        Yields:
            TokenizeResponse: The Tokenized input
        """
        try:
            params = TokenParams(return_tokens=return_tokens)
            tokenize_response = self.service.tokenize(self.model, inputs, params)

            if tokenize_response.status_code == 200:
                responses = TokenizeResponse(**tokenize_response.json())
                for token in responses.results:
                    yield token

            else:
                raise BAMException(tokenize_response)
        except BAMException as me:
            raise me
        except Exception as ex:
            raise BAMException(ex)

    def tokenize(self, inputs: list[str], return_tokens: bool = False) -> list[TokenizeResult]:
        """The tokenize endpoint allows you to check the conversion of provided inputs to tokens
        for a given model. It splits text into words or subwords, which then are converted to ids
        through a look-up table (vocabulary). Tokenization allows the model to have a reasonable
        vocabulary size.

        Args:
            return_tokens (bool, optional): Return tokens with the response. Defaults to False.

        Returns:
            list[TokenizeResult]: The Tokenized input
        """
        return list(self.tokenize_as_completed(inputs, return_tokens))
