import asyncio
import logging
from concurrent.futures import ThreadPoolExecutor
from queue import Empty, Queue

from bampy.schemas.responses import GenerateResponse


class AsyncRequestHelper:
    RETRY_LIMIT = 3
    RATELIMIT = 5
    EPSILON = 0.02
    DEFAULT_MAX_PROMPTS = 5

    def __init__(self, model_id, prompts, params, service, callback=None):
        self.model_id = model_id
        self.prompts = prompts
        self.params = params
        self.service = service
        self.callback = callback

    def __enter__(self):
        self.loop_ = asyncio.new_event_loop()
        self.queue_ = Queue()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        try:
            self.loop_.close()
            while not self.queue_.empty():
                _ = self.queue_.get()
                self.queue_.task_done()
            self.queue_.join()
        except Exception as e:
            print(e)

    @staticmethod
    async def _get_generate_json(model, inputs, params, service):
        response_raw = await service.async_generate(model, inputs, params)
        response = await response_raw.json()
        return response

    async def _generate_task(self, inputs, retry_queue, attempt=0):
        response = None
        try:
            response = await self._get_generate_json(self.model_id, inputs, self.params, self.service)
            if "status_code" in response and response["status_code"] == 429:
                raise Exception("Too many requests due to in-flight variability, retrying.")
            response = GenerateResponse(**response)
        except Exception as e:
            logging.warning("Exception raised async_generate : {}".format(e))
            if attempt < AsyncRequestHelper.RATELIMIT:
                retry_queue.put_nowait((inputs, attempt + 1))
            return
        self.queue_.put_nowait(response)
        if self.callback is not None:
            for r in response.results:
                self.callback(r)

    async def _schedule_requests(self):
        retry_queue = asyncio.Queue()
        tasks = []
        for i in range(0, len(self.prompts), AsyncRequestHelper.DEFAULT_MAX_PROMPTS):
            inputs = self.prompts[i : min(i + AsyncRequestHelper.DEFAULT_MAX_PROMPTS, len(self.prompts))]
            retry_queue.put_nowait((inputs, 0))  # 0 => first attempt. Put task in the queue.
            while not retry_queue.empty():  # finish all pending tasks in the retry queue
                inputs, attempt = await retry_queue.get()
                retry_queue.task_done()
                task = asyncio.create_task(self._generate_task(inputs, retry_queue, attempt))
                tasks.append(task)
                await asyncio.sleep(1 / AsyncRequestHelper.RATELIMIT + AsyncRequestHelper.EPSILON)
        await asyncio.gather(*tasks)

    def _generate_launcher(self):
        asyncio.set_event_loop(self.loop_)
        self.loop_.run_until_complete(self._schedule_requests())

    def generate(self):
        with ThreadPoolExecutor(max_workers=1) as executor:
            executor.submit(self._generate_launcher)
            counter = 0
            total_requests = 0
            if len(self.prompts) > 0:
                a, b = len(self.prompts), AsyncRequestHelper.DEFAULT_MAX_PROMPTS
                total_requests = a // b + (a % AsyncRequestHelper.DEFAULT_MAX_PROMPTS > 0)
            while counter < total_requests:
                try:
                    counter += 1
                    item = self.queue_.get(timeout=10)  # give up if no item for ten seconds
                    self.queue_.task_done()
                    yield item
                except Empty as timeout:
                    raise timeout
                except Exception as ex:
                    logging.error("Exception while reading from queue: {}".format(ex))
                    raise ex
