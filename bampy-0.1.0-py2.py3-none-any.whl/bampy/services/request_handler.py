import aiohttp
import requests


class RequestHandler:
    @staticmethod
    def _metadata(method: str, key: str, model_id: str = None, inputs: list = None, parameters: dict = None):
        """General function to build header and/or json_data for /post and /get requests.

        Args:
            method (str): Request type. Currently accepts GET or POST
            key (str): API key for authorization.
            model_id (str, optional): The id of the language model to be queried. Defaults to None.
            inputs (list, optional): List of inputs to be queried. Defaults to None.
            parameters (dict, optional): Key-value pairs for model parameters. Defaults to None.

        Returns:
            dict,dict: Headers, json_data for request
        """

        if method == "GET":
            return {"Authorization": f"Bearer {key}"}

        elif method == "POST":
            headers = {
                "Content-Type": "application/json",
                "Authorization": f"Bearer {key}",
            }

            json_data = {}

            if model_id is not None:
                json_data["model_id"] = model_id

            if inputs is not None:
                json_data["inputs"] = inputs

            if parameters is not None:
                json_data["parameters"] = parameters

            return headers, json_data

    @staticmethod
    async def async_post(endpoint: str, key: str, model_id: str = None, inputs: list = None, parameters: dict = None):
        """Low level API for async /post request to REST API.

        Args:
            endpoint (str): Remote endpoint to be queried.
            key (str): API key for authorization.
            model_id (str, optional): The id of the language model to be queried. Defaults to None.
            inputs (list, optional): List of inputs to be queried. Defaults to None.
            parameters (dict, optional): Key-value pairs for model parameters. Defaults to None.

        Returns:
            requests.models.Response: Response from the REST API.
        """
        headers, json_data = RequestHandler._metadata(
            method="POST", key=key, model_id=model_id, inputs=inputs, parameters=parameters
        )
        response = None

        async with aiohttp.ClientSession() as session:
            response = await session.post(endpoint, headers=headers, json=json_data)
        return response

    @staticmethod
    async def async_get(endpoint: str, key: str, parameters: dict = None):
        """Low level API for async /get request to REST API.

        Args:
            endpoint (str): Remote endpoint to be queried.
            key (str): API key for authorization.
            parameters (dict, optional): Key-value pairs for model parameters. Defaults to None.

        Returns:
            requests.models.Response: Response from the REST API.
        """
        headers = RequestHandler._metadata(method="GET", key=key)

        async with aiohttp.ClientSession() as session:
            response = await session.get(url=endpoint, headers=headers, params=parameters)
        return response

    @staticmethod
    def post(endpoint: str, key: str, model_id: str = None, inputs: list = None, parameters: dict = None):
        """Low level API for /post request to REST API.

        Args:
            endpoint (str): Remote endpoint to be queried.
            key (str): API key for authorization.
            model_id (str, optional): The id of the language model to be queried. Defaults to None.
            inputs (list, optional): List of inputs to be queried. Defaults to None.
            parameters (dict, optional): Key-value pairs for model parameters. Defaults to None.

        Returns:
            requests.models.Response: Response from the REST API.
        """
        headers, json_data = RequestHandler._metadata(
            method="POST", key=key, model_id=model_id, inputs=inputs, parameters=parameters
        )
        with requests.Session() as s:
            response = s.post(endpoint, headers=headers, json=json_data)
            response.close()
            return response

    @staticmethod
    def get(endpoint: str, key: str, parameters: dict = None):
        """Low level API for /get request to REST API.

        Args:
            endpoint (str): Remote endpoint to be queried.
            key (str): API key for authorization.
            parameters (dict, optional): Key-value pairs for model parameters. Defaults to None.

        Returns:
            requests.models.Response: Response from the REST API.
        """
        headers = RequestHandler._metadata(method="GET", key=key)
        with requests.Session() as s:
            response = s.get(endpoint, headers=headers, params=parameters)
            response.close()
            return response
